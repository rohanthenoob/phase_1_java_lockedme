package program.java.lockedme;

import java.io.File;
import java.util.Scanner;

public class SearchFile {
	public void Find()
	{
		Scanner sc = new Scanner(System.in);
		
		

		String path = "C:\\Users\\ROHAN\\eclipse-workspace\\Phase_1_Java";
		System.out.println("Enter name of the file to be searched : ");
		String filename = sc.nextLine();
		File thisFile = new File(filename);
		if(filename.equalsIgnoreCase(filename))  
		{
		if(thisFile.exists())
		{
			   System.out.println("File exists!" + thisFile);
			}else
			{
			   System.out.println("File is not in directory");
			}
	}
}
}

