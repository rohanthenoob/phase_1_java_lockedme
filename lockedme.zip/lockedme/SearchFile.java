package program.java.lockedme;

import java.io.File;
import java.util.Scanner;

public class SearchFile {
	public void Find()
	{
		Scanner sc = new Scanner(System.in);
		String filename = sc.nextLine();

		String path = "C:\\Users\\ROHAN\\eclipse-workspace\\Phase_1_Java";
		File thisFile = new File(path + "/" + filename);
		if(thisFile.exists()){
			   System.out.println("File exists!");
			}else{
			   System.out.println("File is not in directory");
			}
	}
}
