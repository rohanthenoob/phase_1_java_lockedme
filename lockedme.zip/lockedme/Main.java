package program.java.lockedme;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		FileCreate Fc = new FileCreate();
		AssendingFiles Ass = new AssendingFiles();
		Delete d = new Delete();
		SearchFile s = new SearchFile();
		int option;
		int option2;
        Scanner in1 = new Scanner(System.in);
        Scanner in = new Scanner(System.in);
        do {
            do {
                String menu = "\n Please select an option to perform"
                                + "\n1  See the files."
                                + "\n2  Create,Delete and Search."
                                
                                + "\n3 Exit Program";
                               System.out.println(menu);
                option = in.nextInt();
            } while(option < 0 || option > 4); // This will make the menu repeat if option is higher than 4 or lowen than 0.

            switch(option)
            {
                case 1:
                	System.out.println("see a new file");
            		Ass.userInput();
                    break;
                case 2:
                	
                	do {
        	            do {
        	                String menu = "\n Please select an option to perform"
        	                                + "\n1  Add the files."
        	                                + "\n2  Delete the file."
        	                                + "\n3  Search the file"
        	                                + "\n0  Exit Program";
        	                               System.out.println(menu);
        	                option2 = in1.nextInt();
        	            } 
        				while(option2 < 0 || option2 > 4); 

        	            switch(option2)
        				{
        	                case 1:
        	                	 Fc.Fcreate();
        					break;
        	               case 2:
        				   d.Dels();
        					break;
        					case 3:
        				   s.Find();
        					break;
        	               default:
        	                    System.out.println("good bye");
        	                    break;  //use this break, even when not needed.
        	            }
        	        } 
        	        while (option2 != 0);
        	    break;
                default:
                    System.out.println("Hasta la vista Baby, We are on main menu ");
                    break;  
            }
        } 
        while (option != 0);
    }
}
