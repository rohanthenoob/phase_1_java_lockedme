package program.java.lockedme;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class AssendingFiles {

	public void userInput() 
	{
		File directory = new File("C:\\Users\\ROHAN\\eclipse-workspace\\Phase_1_Java");
		if(directory.isDirectory()){
			List<String> listFile = Arrays.asList(directory.list());
			System.out.println("Listing files unsorted");
			for(String s:listFile){
				System.out.println(s);
			}
			Collections.sort(listFile);
			System.out.println("........................................");
			System.out.println("Sorting by filename in ascending order");
			for(String s:listFile){
				System.out.println(s);
			}

		}
		else{
			System.out.println(directory.getAbsolutePath() + " is not a directory");
		}

	}

}