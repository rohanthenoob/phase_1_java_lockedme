package program.java.lockedme;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class FileCreate {
	public void Fcreate() 
	{
		  Scanner reader = new Scanner(System.in);
	        boolean success = false;

	      System.out.println("C:\\Users\\ROHAN\\eclipse-workspace\\Phase_1_Java");
	      /* String dir = reader.nextLine();

	                                                        // Creating new directory in Java, if it doesn't exists
	        File directory = new File(dir);
	        if (directory.exists()) {
	            System.out.println("Directory already exists ...");

	        } else {
	            System.out.println("Directory not exists, creating now");

	            success = directory.mkdir();
	            if (success) {
	                System.out.printf("Successfully created new directory : %s%n", dir);
	            } else {
	                System.out.printf("Failed to create new directory: %s%n", dir);
	            }
	        }*/
	                                                                 // Creating new file in Java, only if not exists
	        System.out.println("Enter file name to be created ");
	        String filename = reader.nextLine();
	        try
	        {
	        File f = new File(filename);
	       
	        if (f.exists()) {
	            System.out.println("File already exists");

	        } else {
	            System.out.println("No such file exists, creating now");
	            success = f.createNewFile();
	            if (success) {
	                System.out.printf("Successfully created new file: %s%n", f);
	            } else {
	                System.out.printf("Failed to create new file: %s%n", f);
	            }
	        }
	        }
	        catch(IOException io) {
	            io.printStackTrace();
	        }
	}
	

}
