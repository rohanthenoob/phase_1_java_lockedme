package program.java.lockedme;

import java.io.File;
import java.util.Scanner;

public class Delete {

	public void Dels()  
	{
		  Scanner del = new Scanner(System.in);

	      System.out.println("C:\\Users\\ROHAN\\eclipse-workspace\\Phase_1_Java");
	          System.out.println("Enter file name to be deleted ");
                String filename = del.nextLine();
     File f = new File(filename);
    
     if(f.delete()) 
     { 
         System.out.println("File deleted successfully"); 
     } 
     else
     { 
         System.out.println("File not found"); 
     }
	}
}